"""
tests/test_structures.py
------------------------
Unit test untuk semua struktur data.
Jalankan: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from models.note import Note, SyncStatus
from structures.chron_list import ChronList
from structures.alpha_list import AlphaList
from structures.tag_manager import TagManager
from structures.sync_buffer import SyncBuffer, SyncChange, ChangeType
from note_app import NoteApp


# ======================================================================
# ChronList
# ======================================================================

class TestChronList:
    def test_insert_prepend(self):
        cl = ChronList()
        n1 = Note(title="Note 1", content="")
        n2 = Note(title="Note 2", content="")
        cl.insert(n1)
        cl.insert(n2)
        assert cl.head is n2       # terbaru di head
        assert cl.tail is n1
        assert len(cl) == 2

    def test_traverse(self):
        cl = ChronList()
        notes = [Note(title=f"N{i}", content="") for i in range(3)]
        for n in notes:
            cl.insert(n)
        result = list(cl.traverse())
        assert result[0] is notes[-1]   # terbaru dulu

    def test_remove_head(self):
        cl = ChronList()
        n1, n2, n3 = [Note(title=f"N{i}", content="") for i in range(3)]
        for n in [n1, n2, n3]:
            cl.insert(n)
        cl.remove(cl.head)             # hapus n3 (head)
        assert cl.head is n2
        assert len(cl) == 2

    def test_remove_tail(self):
        cl = ChronList()
        n1, n2 = Note(title="A", content=""), Note(title="B", content="")
        cl.insert(n1)
        cl.insert(n2)
        cl.remove(n1)                  # hapus tail
        assert cl.tail is n2
        assert len(cl) == 1

    def test_find(self):
        cl = ChronList()
        note = Note(title="Cari saya", content="")
        cl.insert(note)
        assert cl.find(note.id) is note
        assert cl.find("tidak-ada") is None


# ======================================================================
# AlphaList
# ======================================================================

class TestAlphaList:
    def test_sorted_insert(self):
        al = AlphaList()
        for title in ["Zebra", "Apple", "Mango", "Banana"]:
            al.insert(Note(title=title, content=""))
        result = [n.title for n in al.traverse()]
        assert result == sorted(result, key=str.lower)

    def test_insert_single(self):
        al = AlphaList()
        n = Note(title="Solo", content="")
        al.insert(n)
        assert al.head is n
        assert al.tail is n

    def test_remove_middle(self):
        al = AlphaList()
        titles = ["Apple", "Banana", "Cherry"]
        notes = {t: Note(title=t, content="") for t in titles}
        for n in notes.values():
            al.insert(n)
        al.remove(notes["Banana"])
        result = [n.title for n in al.traverse()]
        assert result == ["Apple", "Cherry"]

    def test_update_title_reorders(self):
        al = AlphaList()
        n1 = Note(title="Apple", content="")
        n2 = Note(title="Cherry", content="")
        al.insert(n1)
        al.insert(n2)
        al.update_title(n1, "Zucchini")
        result = [n.title for n in al.traverse()]
        assert result == ["Cherry", "Zucchini"]

    def test_reverse_traverse(self):
        al = AlphaList()
        for t in ["C", "A", "B"]:
            al.insert(Note(title=t, content=""))
        result = [n.title for n in al.traverse(reverse=True)]
        assert result == ["C", "B", "A"]


# ======================================================================
# TagManager
# ======================================================================

class TestTagManager:
    def _setup(self):
        tm = TagManager()
        tag = tm.create_tag("python", "#3776AB")
        note = Note(title="Intro Python", content="")
        return tm, tag, note

    def test_add_tag(self):
        tm, tag, note = self._setup()
        tm.add_tag(note, tag)
        assert tag.note_count == 1
        assert tm.has_tag(note, tag)

    def test_add_duplicate_tag(self):
        tm, tag, note = self._setup()
        tm.add_tag(note, tag)
        tm.add_tag(note, tag)            # duplikat diabaikan
        assert tag.note_count == 1

    def test_remove_tag(self):
        tm, tag, note = self._setup()
        tm.add_tag(note, tag)
        result = tm.remove_tag(note, tag)
        assert result is True
        assert not tm.has_tag(note, tag)
        assert tag.note_count == 0

    def test_get_notes_by_tag(self):
        tm = TagManager()
        tag = tm.create_tag("data-science")
        notes = [Note(title=f"DS Note {i}", content="") for i in range(3)]
        for n in notes:
            tm.add_tag(n, tag)
        found_ids = {nt.note_id for nt in tm.get_notes_by_tag(tag)}
        assert found_ids == {n.id for n in notes}

    def test_multiple_tags_per_note(self):
        tm = TagManager()
        tags = [tm.create_tag(name) for name in ["python", "ml", "nlp"]]
        note = Note(title="Transformer paper", content="")
        for tag in tags:
            tm.add_tag(note, tag)
        assert len(tm.get_tag_ids_by_note(note)) == 3


# ======================================================================
# SyncBuffer
# ======================================================================

class TestSyncBuffer:
    def _change(self, note_id="note-1", ctype=ChangeType.CREATED):
        return SyncChange(note_id=note_id, change_type=ctype)

    def test_enqueue_dequeue(self):
        buf = SyncBuffer(capacity=5)
        c = self._change()
        buf.enqueue(c)
        assert len(buf) == 1
        result = buf.dequeue()
        assert result is c
        assert buf.is_empty

    def test_overwrite_when_full(self):
        buf = SyncBuffer(capacity=3)
        changes = [self._change(note_id=f"note-{i}") for i in range(5)]
        for c in changes:
            buf.enqueue(c)
        # Hanya 3 yang tersisa; 2 terlama sudah tertimpa
        assert len(buf) == 3
        pending = buf.get_all_pending()
        assert pending[0].note_id == "note-2"   # terlama yang tersisa
        assert pending[-1].note_id == "note-4"  # terbaru

    def test_flush(self):
        buf = SyncBuffer(capacity=10)
        for i in range(4):
            buf.enqueue(self._change(note_id=f"note-{i}"))
        flushed = buf.flush()
        assert len(flushed) == 4
        assert buf.is_empty

    def test_peek_no_consume(self):
        buf = SyncBuffer(capacity=5)
        c = self._change()
        buf.enqueue(c)
        assert buf.peek() is c
        assert len(buf) == 1

    def test_fifo_order(self):
        buf = SyncBuffer(capacity=5)
        ids = [f"note-{i}" for i in range(3)]
        for nid in ids:
            buf.enqueue(self._change(note_id=nid))
        result_ids = [buf.dequeue().note_id for _ in range(3)]
        assert result_ids == ids


# ======================================================================
# NoteApp (integrasi)
# ======================================================================

class TestNoteApp:
    def test_create_note_registers_to_all_lists(self):
        app = NoteApp()
        note = app.create_note("Hello World")
        assert len(app.chron_list) == 1
        assert len(app.alpha_list) == 1
        assert len(app.sync_buffer) == 1

    def test_delete_note_cleans_up(self):
        app = NoteApp()
        note = app.create_note("Temp")
        app.delete_note(note)
        assert len(app.chron_list) == 0
        assert len(app.alpha_list) == 0
        assert app.get_note(note.id) is None

    def test_chron_view_order(self):
        app = NoteApp()
        n1 = app.create_note("First")
        n2 = app.create_note("Second")
        n3 = app.create_note("Third")
        view = app.view_chronological()
        assert view[0] is n3  # terbaru duluan

    def test_alpha_view_order(self):
        app = NoteApp()
        for title in ["Zebra", "Apple", "Mango"]:
            app.create_note(title)
        view = [n.title for n in app.view_alphabetical()]
        assert view == sorted(view, key=str.lower)

    def test_tag_note_and_query(self):
        app = NoteApp()
        tag = app.create_tag("python")
        n1 = app.create_note("Learn Python")
        n2 = app.create_note("Django Tutorial")
        n3 = app.create_note("Unrelated Note")
        app.tag_note(n1, tag)
        app.tag_note(n2, tag)
        tagged = app.get_notes_by_tag(tag)
        tagged_ids = {n.id for n in tagged}
        assert n1.id in tagged_ids
        assert n2.id in tagged_ids
        assert n3.id not in tagged_ids

    def test_sync_mark_synced(self):
        app = NoteApp()
        note = app.create_note("Sync me")
        changes = app.mark_synced()
        assert len(changes) == 1
        assert note.sync_status == SyncStatus.SYNCED
        assert app.sync_buffer.is_empty
