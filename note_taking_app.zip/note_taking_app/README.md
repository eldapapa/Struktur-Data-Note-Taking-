# Note-Taking App — Data Structures

Implementasi struktur data untuk aplikasi note-taking yang mendukung tiga fitur utama:

| Fitur | Struktur Data |
|---|---|
| Multiple tags per note | Multi-linked list (per tag) |
| Chronological & alphabetical views | Doubly linked list (sorted) |
| Sync status tracking | Circular buffer |

---

## Struktur Proyek

```
note_taking_app/
├── models/
│   ├── note.py          # Entitas Note + SyncStatus enum
│   └── tag.py           # Entitas Tag + NoteTag junction node
├── structures/
│   ├── chron_list.py    # Doubly linked list — chronological
│   ├── alpha_list.py    # Doubly linked list — alphabetical (sorted)
│   ├── tag_manager.py   # Multi-linked list per tag
│   └── sync_buffer.py   # Circular buffer sync tracking
├── tests/
│   └── test_structures.py
├── note_app.py          # Facade — menyatukan semua struktur
└── main.py              # Demo interaktif
```

---

## Cara Menjalankan

### Requirements
Python 3.8+. Tidak ada dependency eksternal.

### Demo
```bash
python main.py
```

### Tests
```bash
pip install pytest
python -m pytest tests/ -v
```

---

## Detail Struktur Data

### 1. Doubly Linked List — Chronological View

Setiap `Note` menyimpan pointer `prev_chron` dan `next_chron`.  
Head = note terbaru, tail = note terlama.

```
HEAD ←→ Note(terbaru) ←→ Note ←→ Note ←→ Note(terlama) → TAIL
```

- `insert`: O(1) — selalu prepend di head  
- `remove`: O(1) — relink pointer  
- `traverse`: O(n)

---

### 2. Doubly Linked List — Alphabetical View

Pointer terpisah `prev_alpha` dan `next_alpha` pada node `Note` yang sama.  
Dua linked list berbeda, satu node. Mengubah urutan alpha tidak mengganggu urutan chrono.

```
HEAD ←→ "Apple" ←→ "Banana" ←→ "Mango" ←→ "Zebra" → TAIL
```

- `insert`: O(n) — cari posisi yang tepat  
- `remove`: O(1)  
- `update_title`: O(n) — remove + reinsert

---

### 3. Multi-Linked List — Multiple Tags per Note

Setiap `Tag` memiliki doubly linked list `NoteTag`-nya sendiri.  
Satu `Note` bisa berada di banyak list tag sekaligus tanpa duplikasi data.

```
Tag "python"  → NoteTag → NoteTag → NoteTag → None
Tag "ml"      → NoteTag → NoteTag → None
Tag "web"     → NoteTag → None

Note "Django" berada di list "python" DAN "web" sekaligus.
```

- `add_tag`: O(1)  
- `remove_tag`: O(1) via hash index  
- `get_notes_by_tag`: O(k), k = jumlah note bertag tersebut

---

### 4. Circular Buffer — Sync Tracking

Buffer fixed-size (default 50 slot) untuk melacak perubahan terkini.  
Saat penuh, entri terlama otomatis tertimpa.

```
[slot 0] SyncChange(CREATED, note-A)
[slot 1] SyncChange(UPDATED, note-B)
[slot 2] SyncChange(DELETED, note-C)
  ↑ head                         ↑ tail
```

- `enqueue`: O(1)  
- `dequeue`: O(1)  
- `flush`: O(n) — panggil setelah berhasil sync ke server

---

## Diagram Relasi

```
            ┌──────────────────────────────────┐
            │             Note                 │
            │  id, title, content              │
            │  prev_chron ←→ next_chron        │  ← ChronList
            │  prev_alpha ←→ next_alpha        │  ← AlphaList
            │  sync_status                     │
            └───────────┬──────────────────────┘
                        │ 1:N via NoteTag
            ┌───────────▼──────────────────────┐
            │           NoteTag                │
            │  note_id, tag_id                 │
            │  prev_in_tag ←→ next_in_tag      │  ← per-Tag list
            └───────────┬──────────────────────┘
                        │ N:1
            ┌───────────▼──────────────────────┐
            │             Tag                  │
            │  id, name, color                 │
            │  head_note_tag                   │
            └──────────────────────────────────┘

            ┌──────────────────────────────────┐
            │          SyncBuffer              │
            │  [SyncChange, SyncChange, ...]   │
            │  head_idx, tail_idx, count       │
            └──────────────────────────────────┘
```

---

## Kompleksitas Waktu

| Operasi | Kompleksitas |
|---|---|
| Buat note | O(n) *(insert alpha sorted)* |
| Hapus note | O(n) *(cari di alpha list)* |
| Update judul | O(n) *(reposisi alpha)* |
| Get notes by tag | O(k) |
| Get tags by note | O(1) *(hash index)* |
| Enqueue sync change | O(1) |
| Flush sync buffer | O(n) |

---

## Lisensi

MIT
