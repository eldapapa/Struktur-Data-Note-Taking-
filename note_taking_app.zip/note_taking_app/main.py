"""
main.py
-------
Demo interaktif yang menampilkan semua fitur:
  1. Multiple tags per note
  2. Chronological & alphabetical views
  3. Sync status tracking (circular buffer)
"""

from note_app import NoteApp


def separator(title: str = "") -> None:
    line = "─" * 55
    if title:
        print(f"\n{line}")
        print(f"  {title}")
        print(line)
    else:
        print(line)


def main() -> None:
    app = NoteApp(sync_buffer_capacity=10)

    # ------------------------------------------------------------------
    # 1. Buat notes
    # ------------------------------------------------------------------
    separator("1. Membuat notes")
    titles = [
        "Pengenalan Python",
        "Algoritma Sorting",
        "Machine Learning Dasar",
        "Belajar Django",
        "Numpy & Pandas",
    ]
    notes = [app.create_note(t, content=f"Isi dari '{t}'") for t in titles]
    print(f"✓ {len(notes)} notes dibuat.")
    app.summary()

    # ------------------------------------------------------------------
    # 2. Tag notes (multiple tags per note)
    # ------------------------------------------------------------------
    separator("2. Multiple tags per note")
    tag_python  = app.create_tag("python",  "#3776AB")
    tag_ml      = app.create_tag("ml",      "#FF6F00")
    tag_web     = app.create_tag("web",     "#092E20")
    tag_data    = app.create_tag("data",    "#150458")

    app.tag_note(notes[0], tag_python)                        # Python
    app.tag_note(notes[1], tag_python)                        # Python
    app.tag_note(notes[2], tag_python)                        # Python
    app.tag_note(notes[2], tag_ml)                            # Python + ML
    app.tag_note(notes[3], tag_python)                        # Python
    app.tag_note(notes[3], tag_web)                           # Python + Web
    app.tag_note(notes[4], tag_python)                        # Python
    app.tag_note(notes[4], tag_data)                          # Python + Data
    app.tag_note(notes[4], tag_ml)                            # Python + Data + ML

    for tag in [tag_python, tag_ml, tag_web, tag_data]:
        tagged = app.get_notes_by_tag(tag)
        print(f"  #{tag.name} ({len(tagged)} notes):", [n.title for n in tagged])

    print(f"\n  Tags milik '{notes[2].title}':")
    for t in app.tag_manager.get_tags_by_note(notes[2]):
        print(f"    → #{t.name}")

    # ------------------------------------------------------------------
    # 3. Chronological view
    # ------------------------------------------------------------------
    separator("3. Chronological view (terbaru → terlama)")
    app.chron_list.display()

    # ------------------------------------------------------------------
    # 4. Alphabetical view
    # ------------------------------------------------------------------
    separator("4. Alphabetical view (A → Z)")
    app.alpha_list.display()

    # ------------------------------------------------------------------
    # 5. Update note (reposisi di AlphaList)
    # ------------------------------------------------------------------
    separator("5. Update judul → reposisi di AlphaList")
    old_title = notes[0].title
    app.update_note(notes[0], title="Zzz Python Lanjutan")
    print(f"  '{old_title}' → '{notes[0].title}'")
    print("  AlphaList setelah update:")
    app.alpha_list.display()

    # ------------------------------------------------------------------
    # 6. Delete note
    # ------------------------------------------------------------------
    separator("6. Hapus note")
    deleted_title = notes[1].title
    app.delete_note(notes[1])
    print(f"  Note '{deleted_title}' dihapus.")
    print(f"  ChronList size: {len(app.chron_list)}")

    # ------------------------------------------------------------------
    # 7. Sync buffer
    # ------------------------------------------------------------------
    separator("7. Sync buffer (circular buffer)")
    app.sync_buffer.display()

    print("\n  Flush ke server...")
    flushed = app.mark_synced()
    print(f"  {len(flushed)} perubahan di-flush.")
    print(f"  Buffer setelah flush: {len(app.sync_buffer)} item")
    print(f"  Status note[0]: {notes[0].sync_status.value}")

    # ------------------------------------------------------------------
    # 8. Test overwrite circular buffer
    # ------------------------------------------------------------------
    separator("8. Circular buffer overwrite test (kapasitas=3)")
    small_buf_app = NoteApp(sync_buffer_capacity=3)
    for i in range(5):
        small_buf_app.create_note(f"Note overflow {i}")
    print(f"  Dibuat 5 notes, kapasitas buffer=3")
    small_buf_app.sync_buffer.display()

    # ------------------------------------------------------------------
    separator("Selesai!")
    app.summary()


if __name__ == "__main__":
    main()
