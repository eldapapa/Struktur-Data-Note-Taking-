"""
note_app.py
-----------
Facade utama yang menyatukan semua struktur data:
  - ChronList    : doubly linked list chronological view
  - AlphaList    : doubly linked list alphabetical view
  - TagManager   : multi-linked list per tag
  - SyncBuffer   : circular buffer perubahan terkini
"""

from __future__ import annotations
from typing import Optional

from models.note import Note, SyncStatus
from models.tag import Tag
from structures.chron_list import ChronList
from structures.alpha_list import AlphaList
from structures.tag_manager import TagManager
from structures.sync_buffer import SyncBuffer, SyncChange, ChangeType


class NoteApp:
    """
    Aplikasi note-taking dengan tiga fitur utama:
      1. Multiple tags per note  (multi-linked by tag)
      2. Chronological & alphabetical views  (doubly linked sorted)
      3. Sync status tracking  (circular buffer for recent changes)
    """

    def __init__(self, sync_buffer_capacity: int = 50) -> None:
        self.chron_list = ChronList()
        self.alpha_list = AlphaList()
        self.tag_manager = TagManager()
        self.sync_buffer = SyncBuffer(capacity=sync_buffer_capacity)

        # Registry note: note_id → Note
        self._notes: dict[str, Note] = {}

    # ------------------------------------------------------------------
    # Note CRUD
    # ------------------------------------------------------------------

    def create_note(self, title: str, content: str = "") -> Note:
        """
        Buat note baru, daftarkan ke kedua linked list, dan
        catat ke sync buffer.
        """
        note = Note(title=title, content=content)
        self._notes[note.id] = note

        self.chron_list.insert(note)
        self.alpha_list.insert(note)

        self.sync_buffer.enqueue(
            SyncChange(note_id=note.id, change_type=ChangeType.CREATED,
                       payload=note.to_dict())
        )
        return note

    def update_note(
        self,
        note: Note,
        title: Optional[str] = None,
        content: Optional[str] = None,
    ) -> Note:
        """
        Update isi / judul note.
        Jika judul berubah, reposisi node di AlphaList.
        """
        if title and title != note.title:
            self.alpha_list.update_title(note, title)
        if content is not None:
            note.content = content
            note.touch()

        self.sync_buffer.enqueue(
            SyncChange(note_id=note.id, change_type=ChangeType.UPDATED,
                       payload=note.to_dict())
        )
        return note

    def delete_note(self, note: Note) -> bool:
        """
        Hapus note dari semua struktur data.
        """
        if note.id not in self._notes:
            return False

        # Hapus dari kedua linked list
        self.chron_list.remove(note)
        self.alpha_list.remove(note)

        # Hapus semua relasi tag
        for tag in self.tag_manager.get_tags_by_note(note):
            self.tag_manager.remove_tag(note, tag)

        # Catat ke sync buffer
        note.sync_status = SyncStatus.PENDING_DELETE
        self.sync_buffer.enqueue(
            SyncChange(note_id=note.id, change_type=ChangeType.DELETED,
                       payload={"id": note.id})
        )

        del self._notes[note.id]
        return True

    def get_note(self, note_id: str) -> Optional[Note]:
        return self._notes.get(note_id)

    # ------------------------------------------------------------------
    # Tag operations
    # ------------------------------------------------------------------

    def create_tag(self, name: str, color: str = "#6B7280") -> Tag:
        return self.tag_manager.create_tag(name=name, color=color)

    def tag_note(self, note: Note, tag: Tag) -> None:
        self.tag_manager.add_tag(note, tag)

    def untag_note(self, note: Note, tag: Tag) -> None:
        self.tag_manager.remove_tag(note, tag)

    def get_notes_by_tag(self, tag: Tag) -> list[Note]:
        """Semua note yang memiliki tag tertentu."""
        return [
            self._notes[nt.note_id]
            for nt in self.tag_manager.get_notes_by_tag(tag)
            if nt.note_id in self._notes
        ]

    # ------------------------------------------------------------------
    # Views
    # ------------------------------------------------------------------

    def view_chronological(self) -> list[Note]:
        """Kembalikan notes dari terbaru ke terlama."""
        return list(self.chron_list.traverse())

    def view_alphabetical(self) -> list[Note]:
        """Kembalikan notes urutan A–Z."""
        return list(self.alpha_list.traverse())

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    def get_pending_changes(self) -> list[SyncChange]:
        """Semua perubahan yang belum di-sync."""
        return self.sync_buffer.get_all_pending()

    def mark_synced(self) -> list[SyncChange]:
        """
        Flush sync buffer (panggil setelah berhasil kirim ke server).
        Tandai semua note yang masih ada sebagai SYNCED.
        """
        changes = self.sync_buffer.flush()
        for change in changes:
            note = self._notes.get(change.note_id)
            if note:
                note.sync_status = SyncStatus.SYNCED
        return changes

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def summary(self) -> None:
        print("=" * 55)
        print("  NOTE-TAKING APP  —  ringkasan struktur data")
        print("=" * 55)
        print(f"  Total notes     : {len(self._notes)}")
        print(f"  ChronList size  : {len(self.chron_list)}")
        print(f"  AlphaList size  : {len(self.alpha_list)}")
        print(f"  Total tags      : {len(self.tag_manager.list_tags())}")
        print(f"  Pending sync    : {len(self.sync_buffer)}/{self.sync_buffer.capacity}")
        print("=" * 55)
