"""
models/note.py
--------------
Entitas utama Note dengan pointer untuk dua doubly linked list
(chronological & alphabetical) dan sync status.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


class SyncStatus(Enum):
    SYNCED = "synced"
    PENDING_CREATE = "pending_create"
    PENDING_UPDATE = "pending_update"
    PENDING_DELETE = "pending_delete"


@dataclass
class Note:
    """
    Satu node yang berpartisipasi dalam:
      - doubly linked list chronological  (prev_chron / next_chron)
      - doubly linked list alphabetical   (prev_alpha / next_alpha)
    """
    title: str
    content: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    sync_status: SyncStatus = SyncStatus.PENDING_CREATE

    # Pointer chronological list
    prev_chron: Optional[Note] = field(default=None, repr=False)
    next_chron: Optional[Note] = field(default=None, repr=False)

    # Pointer alphabetical list
    prev_alpha: Optional[Note] = field(default=None, repr=False)
    next_alpha: Optional[Note] = field(default=None, repr=False)

    def touch(self) -> None:
        """Update timestamp dan tandai perlu sync ulang."""
        self.updated_at = datetime.now()
        if self.sync_status == SyncStatus.SYNCED:
            self.sync_status = SyncStatus.PENDING_UPDATE

    def __repr__(self) -> str:
        return (
            f"Note(id={self.id[:8]}…, "
            f"title={self.title!r}, "
            f"sync={self.sync_status.value})"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "content": self.content,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "sync_status": self.sync_status.value,
        }
