"""
models/tag.py
-------------
Tag dan NoteTag (junction node).

Setiap Tag memiliki doubly linked list Notes-nya sendiri:
  Tag.head_note_tag → NoteTag.next_in_tag → NoteTag → ...

Dengan ini satu Note bisa terhubung ke banyak Tag tanpa duplikasi.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import uuid


@dataclass
class Tag:
    name: str
    color: str = "#6B7280"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    note_count: int = 0

    # Head dari linked list NoteTag milik tag ini
    head_note_tag: Optional[NoteTag] = field(default=None, repr=False)

    def __repr__(self) -> str:
        return f"Tag(name={self.name!r}, note_count={self.note_count})"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "color": self.color,
            "note_count": self.note_count,
        }


@dataclass
class NoteTag:
    """
    Junction node yang sekaligus merupakan node dalam doubly linked list
    per-tag.  Composite key: (note_id, tag_id).
    """
    note_id: str
    tag_id: str

    # Pointer dalam linked list per-tag
    prev_in_tag: Optional[NoteTag] = field(default=None, repr=False)
    next_in_tag: Optional[NoteTag] = field(default=None, repr=False)

    def __repr__(self) -> str:
        return (
            f"NoteTag(note={self.note_id[:8]}…, "
            f"tag={self.tag_id[:8]}…)"
        )
