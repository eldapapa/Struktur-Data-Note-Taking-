"""
structures/alpha_list.py
------------------------
Doubly Linked List terurut secara alfabetis berdasarkan Note.title.

Operasi:
  insert(note)      → O(n), cari posisi yang tepat lalu sisipkan
  remove(note)      → O(1)
  update_title(...) → O(n), remove + reinsert
  traverse()        → O(n)
"""

from __future__ import annotations
from typing import Optional, Iterator
from models.note import Note


class AlphaList:
    """
    Sorted doubly linked list untuk alphabetical view.
    Urutan: A → Z (case-insensitive).
    """

    def __init__(self) -> None:
        self.head: Optional[Note] = None
        self.tail: Optional[Note] = None
        self.size: int = 0

    # ------------------------------------------------------------------
    # Insert (sorted)
    # ------------------------------------------------------------------

    def insert(self, note: Note) -> None:
        """
        Sisipkan note pada posisi yang menjaga urutan A–Z.
        Kompleksitas: O(n).
        """
        note.prev_alpha = None
        note.next_alpha = None

        # List kosong
        if self.head is None:
            self.head = note
            self.tail = note
            self.size += 1
            return

        # Cari posisi: iterasi sampai menemukan node yang lebih besar
        current = self.head
        while current and current.title.lower() <= note.title.lower():
            current = current.next_alpha

        if current is None:
            # Sisipkan di tail
            note.prev_alpha = self.tail
            self.tail.next_alpha = note  # type: ignore[union-attr]
            self.tail = note
        elif current.prev_alpha is None:
            # Sisipkan di head
            note.next_alpha = self.head
            self.head.prev_alpha = note
            self.head = note
        else:
            # Sisipkan di tengah
            prev_node = current.prev_alpha
            note.prev_alpha = prev_node
            note.next_alpha = current
            prev_node.next_alpha = note
            current.prev_alpha = note

        self.size += 1

    # ------------------------------------------------------------------
    # Remove
    # ------------------------------------------------------------------

    def remove(self, note: Note) -> bool:
        """
        Hapus note dengan relink pointer.
        Kompleksitas: O(1).
        """
        if note.prev_alpha:
            note.prev_alpha.next_alpha = note.next_alpha
        else:
            self.head = note.next_alpha

        if note.next_alpha:
            note.next_alpha.prev_alpha = note.prev_alpha
        else:
            self.tail = note.prev_alpha

        note.prev_alpha = None
        note.next_alpha = None
        self.size -= 1
        return True

    # ------------------------------------------------------------------
    # Update title (reinsert)
    # ------------------------------------------------------------------

    def update_title(self, note: Note, new_title: str) -> None:
        """
        Ubah judul note dan reposisi dalam list.
        Kompleksitas: O(n).
        """
        self.remove(note)
        note.title = new_title
        note.touch()
        self.insert(note)

    # ------------------------------------------------------------------
    # Traversal & find
    # ------------------------------------------------------------------

    def traverse(self, reverse: bool = False) -> Iterator[Note]:
        if not reverse:
            current = self.head
            while current:
                yield current
                current = current.next_alpha
        else:
            current = self.tail
            while current:
                yield current
                current = current.prev_alpha

    def find(self, note_id: str) -> Optional[Note]:
        for note in self.traverse():
            if note.id == note_id:
                return note
        return None

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def display(self) -> None:
        nodes = list(self.traverse())
        if not nodes:
            print("[AlphaList kosong]")
            return
        print(f"AlphaList ({self.size} notes, A → Z):")
        for i, note in enumerate(nodes):
            prefix = "HEAD → " if i == 0 else "       "
            suffix = " ← TAIL" if i == len(nodes) - 1 else ""
            print(f"  {prefix}{note.title!r}{suffix}")

    def __len__(self) -> int:
        return self.size

    def __repr__(self) -> str:
        return f"AlphaList(size={self.size})"
