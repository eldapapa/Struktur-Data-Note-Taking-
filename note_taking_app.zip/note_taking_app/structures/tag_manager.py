"""
structures/tag_manager.py
-------------------------
Multi-linked structure untuk fitur "multiple tags per note".

Setiap Tag punya doubly linked list NoteTag-nya sendiri.
Satu Note bisa berada di banyak linked list tag sekaligus.

Operasi:
  add_tag(note, tag)      → O(1)
  remove_tag(note, tag)   → O(k), k = panjang list tag
  get_notes_by_tag(tag)   → O(k), iterator
  get_tags_by_note(note)  → O(t), t = jumlah tag note
  create_tag(name, color) → O(1)
"""

from __future__ import annotations
from typing import Iterator, Optional
from models.note import Note
from models.tag import Tag, NoteTag


class TagManager:
    """
    Mengelola relasi many-to-many antara Note dan Tag
    menggunakan multi-linked list.
    """

    def __init__(self) -> None:
        # Registry: tag_id → Tag
        self._tags: dict[str, Tag] = {}
        # Index cepat: (note_id, tag_id) → NoteTag
        self._junction: dict[tuple[str, str], NoteTag] = {}
        # Index per-note: note_id → list[tag_id]
        self._note_tags: dict[str, list[str]] = {}

    # ------------------------------------------------------------------
    # Tag CRUD
    # ------------------------------------------------------------------

    def create_tag(self, name: str, color: str = "#6B7280") -> Tag:
        """Buat tag baru. O(1)."""
        tag = Tag(name=name, color=color)
        self._tags[tag.id] = tag
        return tag

    def get_tag_by_name(self, name: str) -> Optional[Tag]:
        for tag in self._tags.values():
            if tag.name.lower() == name.lower():
                return tag
        return None

    def list_tags(self) -> list[Tag]:
        return list(self._tags.values())

    # ------------------------------------------------------------------
    # Tambah / hapus tag pada note
    # ------------------------------------------------------------------

    def add_tag(self, note: Note, tag: Tag) -> NoteTag:
        """
        Hubungkan note ke tag.
        NoteTag baru disisipkan di head linked list tag.
        Kompleksitas: O(1).
        """
        key = (note.id, tag.id)
        if key in self._junction:
            return self._junction[key]   # sudah ada

        nt = NoteTag(note_id=note.id, tag_id=tag.id)

        # Sisipkan di head linked list milik tag
        if tag.head_note_tag is not None:
            nt.next_in_tag = tag.head_note_tag
            tag.head_note_tag.prev_in_tag = nt
        tag.head_note_tag = nt
        tag.note_count += 1

        # Simpan di indeks
        self._junction[key] = nt
        self._note_tags.setdefault(note.id, []).append(tag.id)

        return nt

    def remove_tag(self, note: Note, tag: Tag) -> bool:
        """
        Putuskan relasi note–tag dan relink linked list.
        Kompleksitas: O(1) jika NoteTag ditemukan via indeks.
        """
        key = (note.id, tag.id)
        nt = self._junction.pop(key, None)
        if nt is None:
            return False

        # Relink
        if nt.prev_in_tag:
            nt.prev_in_tag.next_in_tag = nt.next_in_tag
        else:
            tag.head_note_tag = nt.next_in_tag

        if nt.next_in_tag:
            nt.next_in_tag.prev_in_tag = nt.prev_in_tag

        tag.note_count -= 1

        # Bersihkan indeks per-note
        if note.id in self._note_tags:
            self._note_tags[note.id] = [
                tid for tid in self._note_tags[note.id] if tid != tag.id
            ]

        return True

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_notes_by_tag(self, tag: Tag) -> Iterator[NoteTag]:
        """Iterasi semua NoteTag dalam linked list tag. O(k)."""
        current = tag.head_note_tag
        while current:
            yield current
            current = current.next_in_tag

    def get_tag_ids_by_note(self, note: Note) -> list[str]:
        """Semua tag_id yang dimiliki note. O(1)."""
        return self._note_tags.get(note.id, [])

    def get_tags_by_note(self, note: Note) -> list[Tag]:
        """Semua objek Tag yang dimiliki note."""
        return [
            self._tags[tid]
            for tid in self.get_tag_ids_by_note(note)
            if tid in self._tags
        ]

    def has_tag(self, note: Note, tag: Tag) -> bool:
        return (note.id, tag.id) in self._junction

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def display_tag(self, tag: Tag) -> None:
        nodes = list(self.get_notes_by_tag(tag))
        print(f"Tag '{tag.name}' ({tag.note_count} notes):")
        for i, nt in enumerate(nodes):
            arrow = "HEAD → " if i == 0 else "       "
            print(f"  {arrow}NoteTag(note={nt.note_id[:8]}…)")

    def __repr__(self) -> str:
        return (
            f"TagManager(tags={len(self._tags)}, "
            f"junctions={len(self._junction)})"
        )
