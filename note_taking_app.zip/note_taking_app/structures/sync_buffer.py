"""
structures/sync_buffer.py
-------------------------
Circular Buffer fixed-size untuk melacak perubahan terkini (sync tracking).

Saat buffer penuh, perubahan terlama ditimpa secara otomatis.
Cocok untuk menyimpan N perubahan terakhir sebelum di-flush ke server.

Operasi:
  enqueue(change)    → O(1)
  dequeue()          → O(1)
  peek()             → O(1)
  get_all_pending()  → O(n)
  flush()            → O(n), kembalikan semua lalu kosongkan buffer
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class ChangeType(Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"


@dataclass
class SyncChange:
    note_id: str
    change_type: ChangeType
    changed_at: datetime = field(default_factory=datetime.now)
    payload: dict = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"SyncChange("
            f"note={self.note_id[:8]}…, "
            f"type={self.change_type.value}, "
            f"at={self.changed_at:%H:%M:%S})"
        )


class SyncBuffer:
    """
    Circular buffer berkapasitas tetap untuk sync change tracking.

    Struktur internal:
      _buffer : list dengan panjang tetap = capacity
      _head   : indeks slot pertama yang terisi (untuk dequeue)
      _tail   : indeks slot berikutnya yang kosong (untuk enqueue)
      _count  : jumlah item saat ini
    """

    def __init__(self, capacity: int = 50) -> None:
        if capacity < 1:
            raise ValueError("capacity harus ≥ 1")
        self.capacity = capacity
        self._buffer: list[Optional[SyncChange]] = [None] * capacity
        self._head: int = 0   # indeks untuk dequeue
        self._tail: int = 0   # indeks untuk enqueue
        self._count: int = 0

    # ------------------------------------------------------------------
    # Enqueue
    # ------------------------------------------------------------------

    def enqueue(self, change: SyncChange) -> None:
        """
        Tambahkan perubahan ke buffer.
        Jika penuh, timpa entri terlama (overwrite).
        Kompleksitas: O(1).
        """
        if self._count == self.capacity:
            # Overwrite: geser head maju (entri terlama hilang)
            self._head = (self._head + 1) % self.capacity
            self._count -= 1

        self._buffer[self._tail] = change
        self._tail = (self._tail + 1) % self.capacity
        self._count += 1

    # ------------------------------------------------------------------
    # Dequeue
    # ------------------------------------------------------------------

    def dequeue(self) -> Optional[SyncChange]:
        """
        Ambil dan hapus perubahan paling lama.
        Kembalikan None jika buffer kosong.
        Kompleksitas: O(1).
        """
        if self._count == 0:
            return None
        change = self._buffer[self._head]
        self._buffer[self._head] = None
        self._head = (self._head + 1) % self.capacity
        self._count -= 1
        return change

    # ------------------------------------------------------------------
    # Peek
    # ------------------------------------------------------------------

    def peek(self) -> Optional[SyncChange]:
        """Lihat perubahan paling lama tanpa menghapus. O(1)."""
        if self._count == 0:
            return None
        return self._buffer[self._head]

    # ------------------------------------------------------------------
    # Bulk ops
    # ------------------------------------------------------------------

    def get_all_pending(self) -> list[SyncChange]:
        """
        Kembalikan semua item dalam urutan enqueue (lama → baru).
        Tidak mengubah state buffer. O(n).
        """
        result = []
        idx = self._head
        for _ in range(self._count):
            item = self._buffer[idx]
            if item is not None:
                result.append(item)
            idx = (idx + 1) % self.capacity
        return result

    def flush(self) -> list[SyncChange]:
        """
        Kembalikan semua item lalu kosongkan buffer.
        Dipakai saat berhasil sync ke server. O(n).
        """
        pending = self.get_all_pending()
        self._buffer = [None] * self.capacity
        self._head = 0
        self._tail = 0
        self._count = 0
        return pending

    # ------------------------------------------------------------------
    # Properties & display
    # ------------------------------------------------------------------

    @property
    def is_empty(self) -> bool:
        return self._count == 0

    @property
    def is_full(self) -> bool:
        return self._count == self.capacity

    def display(self) -> None:
        pending = self.get_all_pending()
        print(
            f"SyncBuffer ({self._count}/{self.capacity} slot terpakai, "
            f"{'PENUH' if self.is_full else 'ada ruang'}):"
        )
        if not pending:
            print("  [kosong]")
            return
        for i, change in enumerate(pending):
            marker = "← oldest" if i == 0 else ("← newest" if i == len(pending) - 1 else "")
            print(f"  [{i:2d}] {change}  {marker}")

    def __len__(self) -> int:
        return self._count

    def __repr__(self) -> str:
        return (
            f"SyncBuffer(count={self._count}, "
            f"capacity={self.capacity}, "
            f"full={self.is_full})"
        )
