"""
structures/chron_list.py
------------------------
Doubly Linked List terurut berdasarkan created_at (terbaru di head).

Operasi:
  insert(note)  → O(1), selalu prepend (note terbaru selalu paling atas)
  remove(note)  → O(1)
  traverse()    → O(n), iterator dari head ke tail
  find(note_id) → O(n)
"""

from __future__ import annotations
from typing import Optional, Iterator
from models.note import Note


class ChronList:
    """
    Doubly linked list untuk chronological view.
    Head = note terbaru, tail = note terlama.
    """

    def __init__(self) -> None:
        self.head: Optional[Note] = None
        self.tail: Optional[Note] = None
        self.size: int = 0

    # ------------------------------------------------------------------
    # Insert
    # ------------------------------------------------------------------

    def insert(self, note: Note) -> None:
        """
        Prepend note ke head list.
        Kompleksitas: O(1).
        """
        if self.head is None:
            self.head = note
            self.tail = note
            note.prev_chron = None
            note.next_chron = None
        else:
            note.next_chron = self.head
            note.prev_chron = None
            self.head.prev_chron = note
            self.head = note
        self.size += 1

    # ------------------------------------------------------------------
    # Remove
    # ------------------------------------------------------------------

    def remove(self, note: Note) -> bool:
        """
        Hapus note dari list dengan relink pointer.
        Kompleksitas: O(1).
        """
        if note.prev_chron:
            note.prev_chron.next_chron = note.next_chron
        else:
            # note adalah head
            self.head = note.next_chron

        if note.next_chron:
            note.next_chron.prev_chron = note.prev_chron
        else:
            # note adalah tail
            self.tail = note.prev_chron

        note.prev_chron = None
        note.next_chron = None
        self.size -= 1
        return True

    # ------------------------------------------------------------------
    # Traversal
    # ------------------------------------------------------------------

    def traverse(self, reverse: bool = False) -> Iterator[Note]:
        """
        Iterate list.
        reverse=False → head ke tail (terbaru → terlama)
        reverse=True  → tail ke head (terlama → terbaru)
        """
        if not reverse:
            current = self.head
            while current:
                yield current
                current = current.next_chron
        else:
            current = self.tail
            while current:
                yield current
                current = current.prev_chron

    # ------------------------------------------------------------------
    # Find
    # ------------------------------------------------------------------

    def find(self, note_id: str) -> Optional[Note]:
        """Cari note berdasarkan ID. O(n)."""
        for note in self.traverse():
            if note.id == note_id:
                return note
        return None

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def display(self) -> None:
        """Cetak seluruh list ke stdout (untuk debugging)."""
        nodes = list(self.traverse())
        if not nodes:
            print("[ChronList kosong]")
            return
        print(f"ChronList ({self.size} notes, terbaru → terlama):")
        for i, note in enumerate(nodes):
            prefix = "HEAD → " if i == 0 else "       "
            suffix = " ← TAIL" if i == len(nodes) - 1 else ""
            print(f"  {prefix}{note.title!r} ({note.created_at:%Y-%m-%d %H:%M}){suffix}")

    def __len__(self) -> int:
        return self.size

    def __repr__(self) -> str:
        return f"ChronList(size={self.size})"
